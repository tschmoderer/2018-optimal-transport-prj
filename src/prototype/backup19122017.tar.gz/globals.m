%% define flobals variables

global N;
global Q; 

global f0;
global f1;